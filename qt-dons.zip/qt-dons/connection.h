#ifndef CONNECTION_H
#define CONNECTION_H


class connection
{
public:
    connection();
    bool createConnection();
};

#endif // CONNECTION_H
